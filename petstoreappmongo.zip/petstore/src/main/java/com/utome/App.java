package com.utome;
import java.util.List;

import org.bson.types.ObjectId;

public class App {
    public static void main(String[] args) {
        System.out.println("Welcome to pet world!");

        // Create instance of DataAccessObject
        PetStoreDataAccessObject dao = new PetStoreDataAccessObject();
        dao.testConnection();

        int choice = -1;
        while (choice != 0) {
            try {
                System.out.println("Please choose an option (integer)");
                System.out.println(" 1) Show all pets \n 2) Show one pet \n 3) Search for a pet \n 4) Add a pet \n 5) Delete a pet \n 6) Update a pet \n 0) Quit");
                choice = Integer.parseInt(System.console().readLine());

                switch (choice) {
                    case 1:
                        System.out.println("You choose 1) Show all pets.");
                        List<Pet> allPets = dao.getAllPets();
                        for (Pet pet : allPets) {
                            System.out.println(pet);
                        }
                        break;
                    case 2:
                        System.out.println("You choose 2) Show one pet.");
                        System.out.println("Enter the ID of the pet:");
                        String petId = System.console().readLine();
                        Pet onePet = dao.getById(petId);
                        System.out.println(onePet);
                        break;
                    case 3:
                        System.out.println("You choose 3) Search for a pet");
                        System.out.println("Enter the search term:");
                        String searchTerm = System.console().readLine();
                        List<Pet> foundPets = dao.searchForMany(searchTerm);
                        System.out.println("These are the " + foundPets.size() + " pets found for the search term:");
                        for (Pet foundPet : foundPets) {
                            System.out.println(foundPet);
                        }
                        break;
                    case 4:
                        System.out.println("You choose 4) Add a pet.");
                        Pet newPet = new Pet();
                        System.out.println("Enter the name of the pet:");
                        newPet.setName(System.console().readLine());
                        System.out.println("Enter the description of the pet:");
                        newPet.setDescription(System.console().readLine());
                        System.out.println("Enter the price of the pet:");
                        newPet.setPrice(Double.parseDouble(System.console().readLine()));
                        String newPetId = dao.addOne(newPet);
                        System.out.println("The new pet has an id of " + newPetId);
                        break;
                    case 5:
                        System.out.println("You choose 5) Delete a pet.");
                        System.out.println("Enter the ID of the pet to delete:");
                        String deletePetId = System.console().readLine();
                        Pet deletePet = new Pet();
                        deletePet.setId(new ObjectId(deletePetId));
                        long deletes = dao.deleteOne(deletePet);
                        System.out.println(deletes + " deletes applied");
                        break;
                    case 6:
                        System.out.println("You choose 6) Update a pet.");
                        System.out.println("Enter the ID of the pet to update:");
                        String updatePetId = System.console().readLine();
                        Pet updatePet = new Pet();
                        updatePet.setId(new ObjectId(updatePetId));
                        System.out.println("Enter the updated name of the pet:");
                        updatePet.setName(System.console().readLine());
                        System.out.println("Enter the updated description of the pet:");
                        updatePet.setDescription(System.console().readLine());
                        System.out.println("Enter the updated price of the pet:");
                        updatePet.setPrice(Double.parseDouble(System.console().readLine()));
                        Pet updatedPet = dao.updateOne(updatePet);
                        System.out.println("Update applied:");
                        System.out.println(updatedPet);
                        break;
                    case 0:
                        System.out.println("Goodbye");
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}

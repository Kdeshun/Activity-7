package com.utome;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.InsertOneResult;
import com.mongodb.client.FindIterable; 

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

public class PetStoreDataAccessObject {
    String connectionString = "mongodb+srv://muneebulhassan122:musicnow121@cluster0.k1hemfc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

    ServerApi serverApi = ServerApi.builder()
            .version(ServerApiVersion.V1)
            .build();

    MongoClientSettings settings = MongoClientSettings.builder()
            .applyConnectionString(new ConnectionString(connectionString))
            .serverApi(serverApi)
            .build();
            MongoClient mongoClient = MongoClients.create(settings);
            MongoDatabase database = mongoClient.getDatabase("petstore");

            MongoCollection<Document> collection = database.getCollection("petscollection"); 

            public void testConnection(){
            System.out.println("Using database "+database.getName());
            System.out.println("Using collection "+collection.getNamespace());
            }

            public String addOne(Pet newPet) {
                Document document = new Document();
                document.put("NAME", newPet.getName());
                document.put("PRICE", newPet.getPrice());
                document.put("DESCRIPTION", newPet.getDescription());
                InsertOneResult result = collection.insertOne(document);
                return result.getInsertedId().toString();
            }
            public List<Pet> getAllPets() {
                // Start with an empty list
                List<Pet> returnThese = new ArrayList<Pet>();
            
                // Fetch all documents in the collection.
                FindIterable<Document> found = collection.find();
            
                // For each item in the results, create a new pet and add it to the return list.
                for (Document document : found) {
                    Pet p = new Pet();
                    p.setId(document.getObjectId("_id"));
                    p.setName(document.getString("NAME"));
                    p.setPrice(document.getDouble("PRICE"));
                    p.setDescription(document.getString("DESCRIPTION"));
            
                    returnThese.add(p);
                }
            
                // Return a list of all pets
                return returnThese;
            }

            // Find the pet in the database and update changes to its properties.
            public Pet updateOne(Pet p) {
                // Convert pet into a document
                Document update = new Document();
                update.put("NAME", p.getName());
                update.put("PRICE", p.getPrice());
                update.put("DESCRIPTION", p.getDescription());

                // Filter to match the exact id number of a document in the database
                Bson filter = Filters.eq("_id", p.getId());

                // Use findOneAndReplace to overwrite the existing document.
                Document newDocument = collection.findOneAndReplace(filter, update);

                // Attempt to retrieve the newly updated record and return it.
                Pet updatedPet = new Pet();
                try {
                    updatedPet.setId(newDocument.getObjectId("_id"));
                    updatedPet.setName(newDocument.getString("NAME"));
                    updatedPet.setDescription(newDocument.getString("DESCRIPTION"));
                    updatedPet.setPrice(newDocument.getDouble("PRICE"));
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                return updatedPet;
            }

            public ArrayList<Pet> searchForMany(String searchTerm) {
                // Start with an empty list
                ArrayList<Pet> returnThese = new ArrayList<Pet>();
            
                // Create a regular expression to search for a phrase within a string
                String regexString = ".*" + searchTerm + ".*";
            
                // Apply the search filter to the name of the pets
                Bson filter = Filters.regex("NAME", regexString);
                FindIterable<Document> found = collection.find(filter);
            
                for (Document document : found) {
                    Pet p = new Pet();
                    p.setId(document.getObjectId("_id"));
                    p.setName(document.getString("NAME"));
                    p.setPrice(document.getDouble("PRICE"));
                    p.setDescription(document.getString("DESCRIPTION"));
            
                    returnThese.add(p);
                }
            
                return returnThese;
            }

            public long deleteOne(Pet p) {
                Bson filter = Filters.eq("_id", p.getId());
                DeleteResult deleteResult = collection.deleteOne(filter);
                return deleteResult.getDeletedCount();
            }

            // Fetch one pet whose id matches a given string
            public Pet getById(String id) {
                Bson filter = Filters.eq("_id", new ObjectId(id));
                FindIterable<Document> foundItems = collection.find(filter);
                Document foundFirst = foundItems.first();
                
                Pet p = new Pet();
                try {
                    p.setId(foundFirst.getObjectId("_id"));
                    p.setName(foundFirst.getString("NAME"));
                    p.setDescription(foundFirst.getString("DESCRIPTION"));
                    p.setPrice(foundFirst.getDouble("PRICE"));
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                return p;
            }

            
            

            
            

}





